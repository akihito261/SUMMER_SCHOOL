from tealayer_torch import TeaNetwork, TeaTrainer


# This file is intentionally minimal because model_configs, slice_ind,
# pic_size, num_label, X_train, Y_train, X_test, and Y_test are created
# by the notebook data/configuration cells.

def run_example(
    model_configs,
    slice_ind,
    pic_size,
    num_label,
    X_train,
    Y_train,
    X_test,
    Y_test,
    device=None,
):
    model = TeaNetwork(
        model_configs=model_configs,
        slice_ind=slice_ind,
        pic_size=pic_size,
        num_classes=num_label,
    )

    trainer = TeaTrainer(model, device=device)
    history = trainer.fit(
        X_train,
        Y_train,
        batch_size=128,
        epochs=100,
        validation_split=0.2,
        patience=5,
        min_delta=0.001,
    )

    test_loss, test_accuracy = trainer.evaluate(X_test, Y_test)
    return model, trainer, history, test_loss, test_accuracy
