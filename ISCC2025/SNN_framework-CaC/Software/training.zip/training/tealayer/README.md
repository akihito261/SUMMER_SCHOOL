# tealayer_torch

A compact PyTorch package for the TeaLearning portion of the SRAM-based SNN co-design notebook.

## Install

From the `training` directory:

```bash
pip install ./tealayers/tealayer_torch
```

For editable development:

```bash
pip install -e ./tealayers/tealayer_torch
```

## Notebook usage

```python
from tealayer_torch import TeaNetwork, TeaTrainer

model = TeaNetwork(
    model_configs=model_configs,
    slice_ind=slice_ind,
    pic_size=pic_size,
    num_classes=num_label,
)

trainer = TeaTrainer(model, device=device)

history = trainer.fit(
    X_train,
    Y_train,
    batch_size=128,
    epochs=100,
    validation_split=0.2,
    patience=5,
    min_delta=0.001,
)

score = trainer.evaluate(X_test, Y_test)
print("Test Loss:", score[0])
print("Test Accuracy:", score[1])
```

`TeaTrainer` accepts either integer class labels or one-hot labels.

## One-call training

```python
from tealayer_torch import TeaNetwork, train_model

model = TeaNetwork(
    model_configs=model_configs,
    slice_ind=slice_ind,
    pic_size=pic_size,
    num_classes=num_label,
)

result = train_model(
    model,
    X_train,
    Y_train,
    X_test,
    Y_test,
    device=device,
)

print(result["test_loss"])
print(result["test_accuracy"])
```
