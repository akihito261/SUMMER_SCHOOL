from copy import deepcopy

import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


class TeaTrainer:
    """Small training wrapper that keeps the notebook close to Keras-style usage."""

    def __init__(
        self,
        model,
        device=None,
        criterion=None,
        optimizer=None,
        learning_rate=0.001,
    ):
        self.model = model
        self.device = self._resolve_device(device)
        self.model.to(self.device)

        self.criterion = criterion or nn.CrossEntropyLoss()
        self.optimizer = optimizer or torch.optim.Adam(
            self.model.parameters(),
            lr=learning_rate,
            betas=(0.9, 0.999),
            eps=1e-7,
        )

        self.history = {
            "train_loss": [],
            "train_accuracy": [],
            "val_loss": [],
            "val_accuracy": [],
        }

    @staticmethod
    def _resolve_device(device):
        if device is None:
            return torch.device(
                "cuda" if torch.cuda.is_available() else "cpu"
            )
        return torch.device(device)

    @staticmethod
    def _prepare_inputs(inputs):
        if torch.is_tensor(inputs):
            return inputs.detach().clone().float()
        return torch.as_tensor(inputs, dtype=torch.float32)

    @staticmethod
    def _prepare_labels(labels):
        if torch.is_tensor(labels):
            labels = labels.detach().clone()
        else:
            labels = torch.as_tensor(labels)

        if labels.ndim > 1:
            labels = labels.argmax(dim=-1)

        return labels.long()

    @classmethod
    def _make_dataset(cls, inputs, labels):
        return TensorDataset(
            cls._prepare_inputs(inputs),
            cls._prepare_labels(labels),
        )

    @staticmethod
    def _make_loader(dataset, batch_size, shuffle):
        return DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
        )

    def _evaluate_loader(self, data_loader):
        self.model.eval()

        total_loss = 0.0
        total_correct = 0
        total_samples = 0

        with torch.no_grad():
            for inputs, labels in data_loader:
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)

                logits = self.model(inputs)
                loss = self.criterion(logits, labels)

                batch_size = inputs.shape[0]
                total_loss += loss.item() * batch_size
                total_correct += (
                    logits.argmax(dim=1) == labels
                ).sum().item()
                total_samples += batch_size

        if total_samples == 0:
            raise ValueError("Cannot evaluate an empty dataset.")

        return (
            total_loss / total_samples,
            total_correct / total_samples,
        )

    def fit(
        self,
        x,
        y,
        batch_size=128,
        epochs=100,
        validation_split=0.2,
        patience=5,
        min_delta=0.001,
        verbose=1,
        restore_best_weights=False,
    ):
        x_tensor = self._prepare_inputs(x)
        y_tensor = self._prepare_labels(y)

        if len(x_tensor) != len(y_tensor):
            raise ValueError("x and y must contain the same number of samples.")

        if not 0.0 < validation_split < 1.0:
            raise ValueError("validation_split must be between 0 and 1.")

        num_train_samples = int(len(x_tensor) * (1.0 - validation_split))
        if num_train_samples <= 0 or num_train_samples >= len(x_tensor):
            raise ValueError("validation_split creates an empty train or validation set.")

        train_dataset = TensorDataset(
            x_tensor[:num_train_samples],
            y_tensor[:num_train_samples],
        )
        validation_dataset = TensorDataset(
            x_tensor[num_train_samples:],
            y_tensor[num_train_samples:],
        )

        train_loader = self._make_loader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
        )
        validation_loader = self._make_loader(
            validation_dataset,
            batch_size=batch_size,
            shuffle=False,
        )

        self.history = {
            "train_loss": [],
            "train_accuracy": [],
            "val_loss": [],
            "val_accuracy": [],
        }

        best_val_accuracy = -float("inf")
        epochs_without_improvement = 0
        best_state = None

        for epoch in range(epochs):
            self.model.train()

            train_loss_sum = 0.0
            train_correct = 0
            train_samples = 0

            for inputs, labels in train_loader:
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)

                self.optimizer.zero_grad()
                logits = self.model(inputs)
                loss = self.criterion(logits, labels)
                loss.backward()
                self.optimizer.step()

                current_batch_size = inputs.shape[0]
                train_loss_sum += loss.item() * current_batch_size
                train_correct += (
                    logits.argmax(dim=1) == labels
                ).sum().item()
                train_samples += current_batch_size

            train_loss = train_loss_sum / train_samples
            train_accuracy = train_correct / train_samples
            val_loss, val_accuracy = self._evaluate_loader(validation_loader)

            self.history["train_loss"].append(train_loss)
            self.history["train_accuracy"].append(train_accuracy)
            self.history["val_loss"].append(val_loss)
            self.history["val_accuracy"].append(val_accuracy)

            if verbose:
                print(
                    f"Epoch {epoch + 1:03d} | "
                    f"train_loss={train_loss:.6f} | "
                    f"train_acc={train_accuracy:.4f} | "
                    f"val_loss={val_loss:.6f} | "
                    f"val_acc={val_accuracy:.4f}"
                )

            if val_accuracy > best_val_accuracy + min_delta:
                best_val_accuracy = val_accuracy
                epochs_without_improvement = 0
                if restore_best_weights:
                    best_state = deepcopy(self.model.state_dict())
            else:
                epochs_without_improvement += 1

            if epochs_without_improvement >= patience:
                if verbose:
                    print(f"Early stopping at epoch {epoch + 1}")
                break

        if restore_best_weights and best_state is not None:
            self.model.load_state_dict(best_state)

        return self.history

    def evaluate(self, x, y, batch_size=128, verbose=0):
        dataset = self._make_dataset(x, y)
        data_loader = self._make_loader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
        )
        loss, accuracy = self._evaluate_loader(data_loader)

        if verbose:
            print(f"Loss: {loss:.6f}")
            print(f"Accuracy: {accuracy:.4f}")

        return loss, accuracy

    def predict(self, x, batch_size=128, return_probabilities=False):
        inputs = self._prepare_inputs(x)
        placeholder_labels = torch.zeros(len(inputs), dtype=torch.long)
        dataset = TensorDataset(inputs, placeholder_labels)
        data_loader = self._make_loader(
            dataset,
            batch_size=batch_size,
            shuffle=False,
        )

        self.model.eval()
        outputs = []

        with torch.no_grad():
            for batch_inputs, _ in data_loader:
                batch_inputs = batch_inputs.to(self.device)
                logits = self.model(batch_inputs)

                if return_probabilities:
                    outputs.append(torch.softmax(logits, dim=1).cpu())
                else:
                    outputs.append(logits.argmax(dim=1).cpu())

        return torch.cat(outputs, dim=0)


def train_model(
    model,
    x_train,
    y_train,
    x_test=None,
    y_test=None,
    device=None,
    batch_size=128,
    epochs=100,
    validation_split=0.2,
    patience=5,
    min_delta=0.001,
    learning_rate=0.001,
    verbose=1,
    restore_best_weights=False,
):
    """Convenience function for one-call training and optional test evaluation."""
    trainer = TeaTrainer(
        model=model,
        device=device,
        learning_rate=learning_rate,
    )

    history = trainer.fit(
        x=x_train,
        y=y_train,
        batch_size=batch_size,
        epochs=epochs,
        validation_split=validation_split,
        patience=patience,
        min_delta=min_delta,
        verbose=verbose,
        restore_best_weights=restore_best_weights,
    )

    result = {
        "trainer": trainer,
        "history": history,
    }

    if x_test is not None and y_test is not None:
        test_loss, test_accuracy = trainer.evaluate(
            x_test,
            y_test,
            batch_size=batch_size,
        )
        result["test_loss"] = test_loss
        result["test_accuracy"] = test_accuracy

        if verbose:
            print("Test Loss:", test_loss)
            print("Test Accuracy:", test_accuracy)

    return result
