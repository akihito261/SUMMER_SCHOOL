import torch
from torch import nn

from .additive_pooling import AdditivePooling
from .tea import Tea


class TeaNetwork(nn.Module):
    """Build the multi-core Tea network used by the SNN co-design notebook."""

    def __init__(
        self,
        model_configs,
        slice_ind,
        pic_size,
        num_classes,
    ):
        super().__init__()

        self.model_configs = [list(config) for config in model_configs]
        self.slice_ind = [tuple(item) for item in slice_ind]
        self.pic_size = int(pic_size)
        self.num_classes = int(num_classes)

        self._validate_configuration()
        self.tea_layers = nn.ModuleList()

        for layer_ind, config in enumerate(self.model_configs):
            num_cores, _, num_neurons = config
            current_layer = nn.ModuleList()

            if layer_ind == 0:
                for core_ind in range(num_cores):
                    start, end = self.slice_ind[core_ind]
                    input_features = end - start
                    current_layer.append(
                        Tea(
                            input_features=input_features,
                            units=num_neurons,
                        )
                    )
            else:
                previous_num_cores = self.model_configs[layer_ind - 1][0]
                previous_num_neurons = self.model_configs[layer_ind - 1][2]
                cores_per_current_core = previous_num_cores // num_cores
                input_features = (
                    cores_per_current_core * previous_num_neurons
                )

                for _ in range(num_cores):
                    current_layer.append(
                        Tea(
                            input_features=input_features,
                            units=num_neurons,
                        )
                    )

            self.tea_layers.append(current_layer)

        self.additive_pooling = AdditivePooling(self.num_classes)

    def _validate_configuration(self):
        if not self.model_configs:
            raise ValueError("model_configs must contain at least one layer.")

        first_num_cores = self.model_configs[0][0]
        if len(self.slice_ind) != first_num_cores:
            raise ValueError(
                "slice_ind must contain one input slice for each first-layer core."
            )

        for layer_ind, config in enumerate(self.model_configs):
            if len(config) != 3:
                raise ValueError(
                    "Each model configuration must be "
                    "[num_cores, num_axons, num_neurons]."
                )

            num_cores, num_axons, num_neurons = config
            if num_cores <= 0 or num_axons <= 0 or num_neurons <= 0:
                raise ValueError("All model configuration values must be positive.")

            if layer_ind > 0:
                previous_num_cores = self.model_configs[layer_ind - 1][0]
                if previous_num_cores % num_cores != 0:
                    raise ValueError(
                        "The number of cores in a layer must divide the "
                        "number of cores in the previous layer."
                    )

        if self.model_configs[-1][0] != 1:
            raise ValueError("The final layer must contain exactly one core.")

        if self.model_configs[-1][2] % self.num_classes != 0:
            raise ValueError(
                "The number of neurons in the final layer must be divisible "
                "by num_classes."
            )

    def forward(self, x):
        x = x.reshape(x.shape[0], -1)

        layer_outputs = []
        for core_ind, core in enumerate(self.tea_layers[0]):
            start, end = self.slice_ind[core_ind]
            core_input = x[:, start:end]
            layer_outputs.append(core(core_input))

        for layer_ind in range(1, len(self.tea_layers)):
            current_cores = self.tea_layers[layer_ind]
            previous_num_cores = len(layer_outputs)
            current_num_cores = len(current_cores)
            cores_per_current_core = previous_num_cores // current_num_cores
            next_outputs = []

            for core_ind, core in enumerate(current_cores):
                start = core_ind * cores_per_current_core
                end = start + cores_per_current_core
                core_input = torch.cat(layer_outputs[start:end], dim=1)
                next_outputs.append(core(core_input))

            layer_outputs = next_outputs

        return self.additive_pooling(layer_outputs[0])
