import torch
from torch import nn


class RoundSTE(torch.autograd.Function):
    """Round in the forward pass and use a straight-through gradient."""

    @staticmethod
    def forward(ctx, x):
        return torch.round(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output


def round_ste(x):
    """Apply straight-through rounding."""
    return RoundSTE.apply(x)


def tea_weight_initializer(shape, dtype=torch.float32, device=None):
    """Create the fixed alternating +1/-1 Tea weight matrix."""
    if len(shape) != 2:
        raise ValueError("Tea weights must have shape (num_axons, num_neurons).")

    num_axons, num_neurons = int(shape[0]), int(shape[1])
    weights = torch.ones(
        (num_axons, num_neurons),
        dtype=dtype,
        device=device,
    )
    weights[1::2, :] = -1.0
    return weights


class Tea(nn.Module):
    """PyTorch implementation of the TeaLearning layer used by the notebook."""

    def __init__(
        self,
        input_features,
        units,
        use_bias=True,
        round_input=True,
        round_connections=True,
        clip_connections=True,
        round_bias=True,
    ):
        super().__init__()

        self.input_features = int(input_features)
        self.units = int(units)
        self.use_bias = bool(use_bias)
        self.round_input = bool(round_input)
        self.round_connections = bool(round_connections)
        self.clip_connections = bool(clip_connections)
        self.round_bias = bool(round_bias)

        static_weights = tea_weight_initializer(
            (self.input_features, self.units)
        )
        self.register_buffer("static_weights", static_weights)

        self.connections = nn.Parameter(
            torch.empty(self.input_features, self.units)
        )
        nn.init.trunc_normal_(
            self.connections,
            mean=0.5,
            std=0.05,
            a=0.4,
            b=0.6,
        )

        if self.use_bias:
            self.biases = nn.Parameter(torch.zeros(self.units))
        else:
            self.register_parameter("biases", None)

    def forward(self, inputs):
        if inputs.shape[-1] != self.input_features:
            raise ValueError(
                f"Expected {self.input_features} input features, "
                f"but received {inputs.shape[-1]}."
            )

        if self.round_input:
            inputs = round_ste(inputs)

        connections = self.connections

        if self.round_connections:
            connections = round_ste(connections)

        if self.clip_connections:
            connections = torch.clamp(connections, 0.0, 1.0)

        weighted_connections = connections * self.static_weights
        output = torch.matmul(inputs, weighted_connections)

        if self.use_bias:
            biases = self.biases

            if self.round_bias:
                biases = round_ste(biases)

            output = output + biases

        if self.training:
            return torch.sigmoid(output)

        return (output >= 0.0).to(output.dtype)
