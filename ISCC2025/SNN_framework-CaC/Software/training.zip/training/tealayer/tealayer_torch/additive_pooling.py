import torch
from torch import nn


class AdditivePooling(nn.Module):
    """Pool output neurons into class scores by additive voting."""

    def __init__(
        self,
        num_classes,
        use_additive_pooling_processing=False,
        add_pool_process_max=128,
    ):
        super().__init__()

        self.num_classes = int(num_classes)
        self.use_additive_pooling_processing = bool(
            use_additive_pooling_processing
        )
        self.add_pool_process_max = float(add_pool_process_max)

    def forward(self, inputs):
        if inputs.dim() >= 3:
            output = torch.sum(inputs, dim=1)
        else:
            output = inputs

        num_inputs = output.shape[-1]

        if num_inputs % self.num_classes != 0:
            raise ValueError(
                f"{num_inputs} output neurons cannot be evenly divided "
                f"into {self.num_classes} classes."
            )

        neurons_per_class_group = num_inputs // self.num_classes
        output = output.reshape(
            -1,
            neurons_per_class_group,
            self.num_classes,
        )
        output = torch.sum(output, dim=1)

        if self.use_additive_pooling_processing:
            max_output = torch.max(output, dim=1, keepdim=True).values
            scale = self.add_pool_process_max / max_output
            output = output * scale
            output = torch.nan_to_num(output, nan=0.0)

        return output
