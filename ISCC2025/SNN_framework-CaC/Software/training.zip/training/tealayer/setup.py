from setuptools import find_packages, setup


setup(
    name="tealayer-torch",
    version="0.1.0",
    description="PyTorch TeaLearning layers, network, and training utilities",
    packages=find_packages(),
    install_requires=["torch"],
    python_requires=">=3.9",
)
